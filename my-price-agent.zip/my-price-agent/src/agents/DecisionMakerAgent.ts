// src/agents/DecisionMakerAgent.ts
import { FinalPriceResult } from "./DiscountCalculatorAgent.js";

export class DecisionMakerAgent {
  public readonly name = "DecisionMakerAgent";
  public readonly description = "모든 정보를 종합하여 사용자에게 최종 구매 결정을 조언합니다.";

  constructor() {
    console.log(`[${this.name}] 에이전트가 생성되었습니다.`);
  }

  // 최종 조언 메시지를 생성하는 함수
  public run(bestDeal: FinalPriceResult, averagePrice: number): string {
    console.log(`[${this.name}] 최종 조언 생성 시작...`);
    console.log(`- 현재 최저가: ${bestDeal.finalPrice.toLocaleString()}원`);
    console.log(`- 30일 평균가: ${averagePrice.toLocaleString()}원`);

    let advice = "";
    if (bestDeal.finalPrice <= averagePrice) {
      advice = `🎉 지금 구매하기 좋은 시기입니다! 현재 최저가는 30일 평균가보다 저렴하거나 비슷합니다.`;
    } else {
      const difference = bestDeal.finalPrice - averagePrice;
      advice = `🤔 지금은 구매를 잠시 보류하는 것을 추천해요! 현재 최저가는 30일 평균가보다 ${difference.toLocaleString()}원 높습니다. 며칠 더 기다리면 더 좋은 가격이 나올 수 있습니다.`;
    }
    return advice;
  }
}
