// src/agents/DiscountCalculatorAgent.ts

// 이전 단계의 가격 정보 형태
interface PriceResult {
  mall: string;
  price: number;
  url: string;
}

// 할인 정보의 형태
interface DiscountInfo {
  card: string;
  discountRate: number; // 예: 0.07 (7%)
}

// 최종 가격 정보의 형태
export interface FinalPriceResult extends PriceResult {
  finalPrice: number;
  discountInfo?: DiscountInfo;
}

export class DiscountCalculatorAgent {
  public readonly name = "DiscountCalculatorAgent";
  public readonly description = "가격 정보에 카드사 할인, 쿠폰 등을 적용하여 최종 실구매가를 계산합니다.";

  constructor() {
    console.log(`[${this.name}] 에이전트가 생성되었습니다.`);
  }

  // 각 쇼핑몰별 할인 정보를 시뮬레이션합니다.
  private async findDiscounts(mall: string): Promise<DiscountInfo | null> {
    console.log(`[${this.name}] ${mall}의 할인 정보 탐색 중...`);
    // 실제로는 쇼핑몰별 프로모션 페이지를 스크레이핑하거나 API를 호출해야 합니다.
    // 지금은 간단한 시뮬레이션을 위해 쇼핑몰 이름에 따라 다른 할인 정보를 반환합니다.
    if (mall === "G마켓") {
      return { card: "KB국민카드", discountRate: 0.07 }; // 7% 할인
    }
    if (mall === "쿠팡") {
      return { card: "신한카드", discountRate: 0.05 }; // 5% 할인
    }
    return null; // 11번가는 할인 없음
  }

  // 이 에이전트의 메인 실행 함수
  public async run(priceResults: PriceResult[]): Promise<FinalPriceResult[]> {
    console.log(`[${this.name}] 입력 접수: ${priceResults.length}개의 가격 정보`);
    const finalResults: FinalPriceResult[] = [];

    for (const result of priceResults) {
      const discount = await this.findDiscounts(result.mall);
      if (discount) {
        // 할인이 있는 경우
        const finalPrice = Math.floor(result.price * (1 - discount.discountRate));
        finalResults.push({
          ...result,
          finalPrice: finalPrice,
          discountInfo: discount,
        });
        console.log(`[${this.name}] ${result.mall}: ${discount.card} ${discount.discountRate * 100}% 할인 적용! 최종가 ${finalPrice.toLocaleString()}원`);
      } else {
        // 할인이 없는 경우
        finalResults.push({
          ...result,
          finalPrice: result.price, // 최종가는 원가와 동일
        });
        console.log(`[${this.name}] ${result.mall}: 적용 가능한 할인 없음.`);
      }
    }
    return finalResults;
  }
}
