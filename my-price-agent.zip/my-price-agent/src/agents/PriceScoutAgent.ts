// src/agents/PriceScoutAgent.ts
import puppeteer from 'puppeteer-extra';
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import * as cheerio from "cheerio";

// (핵심 수정) TypeScript가 puppeteer-extra의 타입을 잘못 추론하는 문제를 해결하기 위해
// @ts-ignore를 사용하여 타입 검사를 명시적으로 비활성화합니다.
// 코드는 런타임에 정상적으로 작동합니다.
// @ts-ignore
puppeteer.use(StealthPlugin());

export interface PriceResult {
  mall: string;
  price: number;
  url: string;
}

export class PriceScoutAgent {
  public readonly name = "PriceScoutAgent";
  public readonly description = "다나와에서 상품의 실시간 가격 정보를 수집합니다.";

  constructor() {
    console.log(`[${this.name}] 에이전트가 생성되었습니다.`);
  }

  private async scrapePrices(keyword: string): Promise<PriceResult[]> {
    console.log(`[${this.name}] "${keyword}" 키워드로 실제 크롤링 시작... (다나와)`);
    const results: PriceResult[] = [];
    let browser;
    try {
      // @ts-ignore
      browser = await puppeteer.launch({
        headless: true,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-gpu'
        ]
      });

      const page = await browser.newPage();
      await page.setViewport({ width: 1920, height: 1080 });
      
      const danawaUrl = `https://search.danawa.com/dsearch.php?query=${encodeURIComponent(keyword)}`;
      console.log(`[${this.name}] 접속 시도: ${danawaUrl}`);
      await page.goto(danawaUrl, { waitUntil: 'networkidle2', timeout: 30000 });

      const productListSelector = '#product_list';
      console.log(`[${this.name}] 상품 목록(${productListSelector})이 나타나기를 기다리는 중...`);
      await page.waitForSelector(productListSelector, { timeout: 15000 });
      console.log(`[${this.name}] 상품 목록 로딩 완료. HTML 분석 시작...`);

      const content = await page.content();
      const $ = cheerio.load(content);

      $(`${productListSelector} > li.prod_item`).each((i, elem) => {
        if (i >= 5) return;

        const priceElement = $(elem).find('p.price_sect a strong.price_num');
        if(priceElement.length > 0) {
            const priceText = priceElement.text().replace(/,/g, '');
            const price = parseInt(priceText, 10);

            const mallName = $(elem).find('dd.mall_name a').text().trim() || "쇼핑몰 정보 없음";
            const productLink = $(elem).find('p.price_sect a').attr('href');

            if (price && productLink && mallName !== "쇼핑몰 정보 없음") {
              console.log(`[${this.name}] 발견: ${mallName} - ${price.toLocaleString()}원`);
              results.push({
                mall: mallName,
                price: price,
                url: productLink
              });
            }
        }
      });
      console.log(`[${this.name}] 크롤링 완료. 최종 ${results.length}개의 유효한 결과 발견.`);
    } catch (error) {
      console.error(`[${this.name}] 크롤링 중 오류 발생:`, error);
      console.log(`[${this.name}] 페이지 로딩에 실패했거나, 상품 목록을 찾을 수 없습니다. 웹사이트의 구조가 변경되었거나 크롤링이 차단되었을 수 있습니다.`);
    } finally {
      if (browser) {
        await browser.close();
      }
    }
    return results;
  }

  public async run(keyword: string): Promise<PriceResult[]> {
    console.log(`[${this.name}] 입력 접수: "${keyword}"`);
    const results = await this.scrapePrices(keyword);
    return results;
  }
}