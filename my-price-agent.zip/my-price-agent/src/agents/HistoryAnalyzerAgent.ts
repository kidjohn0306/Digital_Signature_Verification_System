// src/agents/HistoryAnalyzerAgent.ts
import fs from 'fs/promises';
import path from 'path';

const historyFilePath = path.join(process.cwd(), 'price_history.json');

interface HistoryData {
  [keyword: string]: { date: string; price: number }[];
}

export class HistoryAnalyzerAgent {
  public readonly name = "HistoryAnalyzerAgent";
  public readonly description = "가격 히스토리 파일을 읽고 분석하여 30일 평균 거래가를 계산합니다.";

  constructor() {
    console.log(`[${this.name}] 에이전트가 생성되었습니다.`);
  }

  private async readHistory(): Promise<HistoryData> {
    try {
      await fs.access(historyFilePath);
      const data = await fs.readFile(historyFilePath, 'utf-8');
      return JSON.parse(data);
    } catch (error) {
      // 파일이 없으면 빈 객체 반환
      return {};
    }
  }

  public async savePrice(keyword: string, price: number): Promise<void> {
    const history = await this.readHistory();
    if (!history[keyword]) {
      history[keyword] = [];
    }
    const today = new Date().toISOString().split('T')[0];
    // 오늘 날짜에 이미 기록이 있으면 업데이트, 없으면 추가
    const todayEntryIndex = history[keyword].findIndex(entry => entry.date === today);
    if (todayEntryIndex > -1) {
        history[keyword][todayEntryIndex].price = price;
    } else {
        history[keyword].push({ date: today, price });
    }
    
    await fs.writeFile(historyFilePath, JSON.stringify(history, null, 2));
    console.log(`[${this.name}] 오늘(${today})의 최저가 ${price.toLocaleString()}원을 히스토리에 저장했습니다.`);
  }

  public async run(keyword: string): Promise<number> {
    console.log(`[${this.name}] 입력 접수: "${keyword}"`);
    const history = await this.readHistory();
    const productHistory = history[keyword];

    if (!productHistory || productHistory.length === 0) {
      console.log(`[${this.name}] 분석할 가격 히스토리가 없습니다.`);
      return 0;
    }

    const total = productHistory.reduce((sum, entry) => sum + entry.price, 0);
    const averagePrice = Math.floor(total / productHistory.length);

    console.log(`[${this.name}] 분석 완료. ${productHistory.length}일간의 평균 거래가: ${averagePrice.toLocaleString()}원`);
    return averagePrice;
  }
}