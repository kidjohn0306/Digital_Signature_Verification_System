
export class UserInputInterpreter {
  public readonly name = "UserInputInterpreter";
  public readonly description = "사용자의 복잡한 검색어를 핵심 상품 키워드로 정제합니다.";

  constructor() {
    console.log(`[${this.name}] 에이전트가 생성되었습니다.`);
  }

  public async run(userInput: string): Promise<string> {
    console.log(`[${this.name}] 입력 접수: "${userInput}"`);

    let keyword = userInput;
    if (userInput.includes("갤럭시 S24")) {
      keyword = "갤럭시 S24 자급제";
    } else if (userInput.includes("아이폰 15")) {
      keyword = "아이폰 15 자급제";
    }

    console.log(`[${this.name}] 정제된 키워드: "${keyword}"`);
    return keyword;
  }
}
