// src/main.ts
import { UserInputInterpreter } from "./agents/UserInputInterpreter.js";
import { PriceScoutAgent } from "./agents/PriceScoutAgent.js";
import { DiscountCalculatorAgent, FinalPriceResult } from "./agents/DiscountCalculatorAgent.js";
import { HistoryAnalyzerAgent } from "./agents/HistoryAnalyzerAgent.js";
import { DecisionMakerAgent } from "./agents/DecisionMakerAgent.js";

async function main() {
  console.log("최저가 탐색 프로그램을 시작합니다.");
  console.log("====================================\n");

  // 1단계: 사용자 입력 분석
  const interpreter = new UserInputInterpreter();
  const userQuery = "갤럭시 S24 자급제"; // 검색어를 명확하게 변경
  const searchKeyword = await interpreter.run(userQuery);
  console.log("====================================\n");

  // 2단계: 실시간 가격 탐색
  const priceScout = new PriceScoutAgent();
  const priceResults = await priceScout.run(searchKeyword);
  console.log("====================================\n");

  // 3단계: 할인 적용 및 최종가 계산
  const calculator = new DiscountCalculatorAgent();
  const finalPriceResults = await calculator.run(priceResults);
  console.log("====================================\n");

  let bestDeal: FinalPriceResult | null = null;
  if (finalPriceResults.length > 0) {
    bestDeal = finalPriceResults.reduce((prev, current) =>
      prev.finalPrice < current.finalPrice ? prev : current
    );
  }

  if (!bestDeal) {
    console.log("가격을 찾을 수 없어 프로그램을 종료합니다.");
    return;
  }

  // 4단계: 가격 히스토리 분석 및 저장
  const historyAnalyzer = new HistoryAnalyzerAgent();
  // (추가) 오늘의 최저가를 히스토리에 저장
  await historyAnalyzer.savePrice(searchKeyword, bestDeal.finalPrice);
  const averagePrice = await historyAnalyzer.run(searchKeyword);
  console.log("====================================\n");

  // 5단계: 최종 구매 조언 생성
  const decisionMaker = new DecisionMakerAgent();
  const finalAdvice = decisionMaker.run(bestDeal, averagePrice);
  console.log("====================================\n");

  // 최종 결과 출력
  console.log("\n✨ AI 소비 어드바이저의 최종 리포트 ✨");
  console.log(`\n[상품명: ${searchKeyword}]`);
  console.log("\n[실시간 최저가 분석]");
  finalPriceResults.forEach(result => {
    if (result.discountInfo) {
      console.log(`- ${result.mall}: ${result.price.toLocaleString()}원 -> [${result.discountInfo.card} ${result.discountInfo.discountRate * 100}%] -> ${result.finalPrice.toLocaleString()}원`);
    } else {
      console.log(`- ${result.mall}: ${result.finalPrice.toLocaleString()}원 (할인 없음)`);
    }
  });

  console.log("\n[구매 결정 가이드]");
  console.log(finalAdvice);
}

main();