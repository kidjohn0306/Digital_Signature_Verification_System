🚀 Quick Start

아래 명령어 세 줄이면 모든 준비가 끝나고 바로 실행됩니다.
실행 후 http://localhost:8080 으로 접속하면 됩니다.

```bash
# 1. 레포지토리 클론
git clone https://github.com/kidjohn0306/Digital_Signature_Verification_System.git

# 2. 프로젝트 폴더로 이동
cd Digital_Signature_Verification_System

# 3. Docker Compose로 백엔드·프론트엔드 컨테이너 실행
docker compose up -d
```